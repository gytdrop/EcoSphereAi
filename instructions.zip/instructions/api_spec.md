POST /login

POST /register

GET /dashboard

GET /environment

POST /environment

GET /csr

POST /csr

GET /governance

POST /governance

POST /ai/advisor

POST /simulate

GET /reports