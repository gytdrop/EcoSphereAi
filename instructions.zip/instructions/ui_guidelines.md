Theme

Modern SaaS Dashboard

Primary

Emerald Green

Cards

Rounded

Shadow

Spacing

24px

Font

Poppins

Inter

Buttons

Rounded

Icons

Lucide

No emojis

No gradients except hero page

Responsive