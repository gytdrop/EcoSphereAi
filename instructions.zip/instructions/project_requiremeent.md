# Project Requirements

EcoSphere AI is an ESG Management Platform.

The application consists of

- Authentication
- Dashboard
- Environmental Module
- Social Module
- Governance Module
- Gamification
- AI Advisor
- Smart ESG Simulator
- Reports

Primary objective

Help organizations monitor and improve ESG performance using Artificial Intelligence.

Expected Users

- Admin
- Sustainability Officer
- HR
- Compliance Officer
- Employees