# Business Rules

## Environmental

Carbon emissions cannot be negative.

Emission Factors are configurable.

Environmental Score ranges from 0 to 100.

---

## Social

Employee participation increases Social Score.

CSR Activity requires approval.

Badges are unlocked automatically.

---

## Governance

Compliance issues have

- Owner
- Due Date

Overdue issues decrease Governance Score.

Policies require acknowledgement.

---

## AI

AI should never invent numbers.

Always explain recommendations.

Never modify database directly.

---

## ESG Formula

Environmental

40%

Social

30%

Governance

30%

Overall ESG

40/30/30