# Users

id

name

email

password

role

department

---

# Carbon Transactions

id

department

emissionFactor

co2Value

date

---

# CSR Activity

title

description

participants

status

---

# Challenges

title

xp

deadline

status

---

# Rewards

points

stock

description

