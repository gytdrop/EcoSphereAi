# AGENT_CONTEXT.md

# EcoSphere AI
### Intelligent ESG Management Platform

---

## Project Vision

EcoSphere AI is an enterprise ESG (Environmental, Social, and Governance) Management Platform developed for the Odoo Hackathon.

The objective of this project is to help organizations monitor, manage, analyze, and improve their ESG performance through a centralized ERP-inspired platform enhanced with Artificial Intelligence.

Unlike traditional ESG systems that only generate reports, EcoSphere AI provides intelligent recommendations and predictive simulations that help organizations make sustainability decisions.

---

# Core Objective

Our platform allows organizations to:

- Monitor Environmental metrics
- Improve Social responsibility
- Maintain Governance compliance
- Measure ESG performance
- Receive AI-powered recommendations
- Simulate future ESG improvements before implementation

---

# Target Users

- Administrator
- Sustainability Manager
- HR Manager
- Compliance Officer
- Employees
- Executive Management

---

# Core Modules

## Authentication

- Secure Login
- Role Based Access Control (RBAC)
- Protected Routes

---

## Dashboard

Displays

- Overall ESG Score
- Environmental Score
- Social Score
- Governance Score
- Carbon Emissions
- Active CSR Activities
- Compliance Issues
- Department Rankings
- Leaderboard

---

## Environmental Module

Responsible for

- Carbon Transactions
- Emission Factors
- Sustainability Goals
- Carbon Reports
- Department Environmental Score

---

## Social Module

Responsible for

- CSR Activities
- Employee Participation
- Community Programs
- Training
- Diversity Metrics

---

## Governance Module

Responsible for

- ESG Policies
- Policy Acknowledgements
- Audits
- Compliance Issues
- Governance Reports

---

## Gamification

Employees can

- Join Challenges
- Earn XP
- Unlock Badges
- Redeem Rewards
- View Leaderboards

Purpose

Increase employee engagement in sustainability initiatives.

---

# Intelligence Layer

This is the unique selling point of EcoSphere AI.

It consists of two intelligent modules.

---

## AI ESG Advisor

Purpose

Analyze organizational ESG data and provide actionable recommendations.

Responsibilities

- Detect ESG weaknesses
- Explain issues
- Suggest improvements
- Prioritize actions
- Generate management insights

Example

Carbon emissions increased by 15%.

Recommendation:

- Improve renewable energy usage.
- Increase CSR participation.
- Resolve pending compliance issues.

---

## Smart ESG Score Simulator

Purpose

Predict future ESG performance before decisions are implemented.

Managers can simulate

- Tree Plantation
- CSR Activities
- Employee Training
- Compliance Resolution
- Carbon Reduction

The simulator predicts

- Environmental Score
- Social Score
- Governance Score
- Final ESG Score

---

# ESG Score Formula

Default Weightage

Environmental = 40%

Social = 30%

Governance = 30%

Overall ESG Score

(Environmental × 0.40)

+

(Social × 0.30)

+

(Governance × 0.30)

The weights should be configurable.

---

# AI Behaviour

You are EcoSphere AI.

Your responsibilities are

- Explain ESG metrics
- Analyze sustainability performance
- Identify organizational risks
- Recommend improvements
- Predict future ESG outcomes
- Help management take better sustainability decisions

Never invent organizational data.

Always answer only using the information supplied.

If data is insufficient, clearly mention what additional information is required.

---

# Design Philosophy

The platform should appear

- Modern
- Professional
- Enterprise Ready
- Clean
- Minimal
- Data Driven

Never produce playful or cartoon-like responses.

---

# Technology Stack

Frontend

- React
- Tailwind CSS

Backend

- Node.js
- Express.js

Database

- PostgreSQL

Charts

- Recharts

Authentication

- JWT

Intelligence Layer

EcoSphere AI uses a hybrid intelligence architecture.

The platform does NOT depend on Large Language Models for core business logic.

Business intelligence is implemented using an internal Rule Engine.

AI (LLM) is optional and used only for generating natural language executive summaries.

The application must function completely even without AI services.
---

# Intelligence Layer

The Intelligence Layer consists of two components.

## Rule Engine

Responsible for

- ESG Score Calculation

- Carbon Analysis

- Recommendation Engine

- Alert Generation

- ESG Prediction

- Compliance Detection

- Badge Assignment

- XP Calculation

No external APIs are required.

The Rule Engine is deterministic and configurable.

---

## AI Executive Advisor

Optional.

Purpose

Convert Rule Engine outputs into professional executive summaries.

If AI services are unavailable,

the Rule Engine recommendations should still be displayed.

# Coding Standards

Follow

- MVC Architecture
- REST API
- Modular Components
- Clean Folder Structure
- Reusable Components
- Proper Error Handling
- Input Validation

---

# API Endpoints

Authentication

POST /login

POST /register

Dashboard

GET /dashboard

Environmental

GET /environment

POST /environment

Social

GET /social

POST /social

Governance

GET /governance

POST /governance

AI

POST /ai/advisor

POST /ai/simulator

Reports

GET /reports

---

# UI Theme

Primary

Emerald Green

Secondary

White

Accent

Dark Slate

Cards

Rounded

Soft Shadows

Minimal Design

---

# Presentation Goal

EcoSphere AI is not just an ESG reporting platform.

It is an Intelligent ESG Decision Support System.

Our platform enables organizations to move beyond monitoring sustainability and start making data-driven sustainability decisions using Artificial Intelligence.

---

# Important

Whenever answering users, think as an enterprise ESG consultant.

Responses should be

- Professional
- Practical
- Business-oriented
- Data-driven

Do not answer like a generic chatbot.

Act like an intelligent sustainability advisor integrated inside an ERP platform.