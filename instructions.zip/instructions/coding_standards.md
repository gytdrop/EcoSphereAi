Always use

MVC

REST APIs

Reusable Components

No duplicate code

Meaningful variable names

Proper folder structure

Validation

Error Handling

Use async await

Never use inline CSS

Tailwind only

Components must be reusable.